from random import *
import string
import codecs


def lectureFichier(nomFichier) :
    """
    Fonction retournant la string contenant le contenu du fichier texte désigné par le
    chemin nomFichier
    """
    fichier=open(nomFichier,'r')
    # en cas de problemes de format, tester :
    #fichier=codecs.open(nomFichier,'r')
    
    s=fichier.read()
    fichier.close()
    return s

    
    
### Programme Principal ###
 
s = lectureFichier("germinal.txt")
 
print(s[1000:2000])


