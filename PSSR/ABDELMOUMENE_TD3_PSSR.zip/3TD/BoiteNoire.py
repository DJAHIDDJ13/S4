import math

def fonction1(x) :
    return (math.log(1+x*x)+math.log(2)+math.pi/2)	

def fonction2(x) :
    return math.asin((2*x)/(1+x*x))

def fonction3(x, y) :
    return (x*y + y*y +1)

def fonction4(x, y, z) :
    return x*x*y*y*y*z
