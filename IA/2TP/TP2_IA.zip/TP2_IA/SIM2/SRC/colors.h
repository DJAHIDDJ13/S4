#ifndef COLOR_H
#define COLOR_H

#define NUMBER_OF_COLORS        39

#define BLACK                   0
#define DIM_GREY                1
#define GREY_69                 2
#define GREY                    3
#define LIGHT_GREY              4
#define WHITE                   5
#define BLUE                    6
#define BLUE_CYAN               7
#define CYAN                    8
#define CYAN_GREEN              9
#define GREEN                   10
#define GREEN_YELLOW            11
#define YELLOW                  12
#define YELLOW_RED              13
#define RED                     14
#define MAGENTA                 15
#define LIME_GREEN              16
#define BROWN                   17
#define MAROON                  18
#define GOLD                    19
#define AQUAMARINE              20
#define FIREBRICK               21
#define GOLDENROD               22
#define BLUE_VIOLET             23
#define CADET_BLUE              24
#define CORAL                   25
#define CORNFLOWER_BLUE         26
#define DARK_GREEN              27
#define DARK_OLIVE_GREEN        28
#define PEACH_PUFF              29
#define PAPAYA_WHIP             30
#define BISQUE                  31
#define AZURE                   32
#define LAVENDER                33
#define MISTY_ROSE              34
#define MEDIUM_BLUE             35
#define NAVY_BLUE               36
#define PALE_TURQUOISE          37
#define SEA_GREEN               38

#define PLATE_UP                0
#define PLATE_DOWN              1
#define PLATE_LOCKED            2

#endif
